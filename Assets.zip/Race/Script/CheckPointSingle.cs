using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Gamandol.Race;

namespace Gamandol.Race
{
    public class CheckPointSingle : MonoBehaviour
    {
        private TrackCheckPoints trackCheckpoints;
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.tag == "Player")
            {
                collision.GetComponent<PlayerCarMLAgents>().PlayerThroughCheckpoint(this);
            }
        }

        public void SetTrackCheckpoints(TrackCheckPoints trackCheckpoints)
        {
            this.trackCheckpoints = trackCheckpoints;
        }
    }
}